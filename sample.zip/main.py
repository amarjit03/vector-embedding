def main():
    print("Hello from main")

if __name__ == "__main__":
    main()